
import sys
import io
import string
import requests
from bs4 import BeautifulSoup
import time,datetime
import xlwt

#访问微信公众号函数，返回网页源码
def get_html(url):
    headers = {
        'User-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36'
         #'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36'
        }
    #cookie_str = r'RK=PSJIKXkoai; ptcz=7ce9c3e21ef9baf1cbb28edd0d05df242d03055a6a8b39a4dd2efcded83a69e0; pgv_pvid=1430614280; pgv_pvi=6390449152; XWINDEXGREY=0; o_cookie=739136979; pac_uid=1_739136979; rewardsn=; wxtokenkey=777; wxuin=2061863542; devicetype=Windows7; version=62070158; lang=zh_CN; pass_ticket=vQCPuxklro6sLz796IWNNW0lkHVj2PiSWKAPJ0SM3xmkRkYVSdZmJFUYIgjUHxwD; wap_sid2=CPaUltcHElxmMWIySDV1czFXeXQ4dzV3aGRockd2aE9UekdTZTJMRkdhUjdXMjZmMDV2Q2tnN3JtbUdQa2xxdG1vRkM3QVpHbVQ4aEJEa0xTLXRheTByQ2ZEazVWdzhFQUFBfjDSjczvBTgNQAE=; pgv_info=ssid=s3324004388; ptisp=ctc; rv2=80886B64CD45195135DD6DF62A4922480AE095E9F26A4E1065; property20=20338BFE043775EA887C6ABFA95A3D55332F2F468AD4AD809A0FBC987529B051DB1338EAEA1FDB3A; pgv_si=s6750715904; tvfe_boss_uuid=2280a21d9dc83a24; vfwebqq=d74f26fae258947b4ad441a0f0c110cdaa4d27402c061320ed18b31bca10727c1b0bdb4299fb6c5f; ied_qq=o0739136979; uin=o0739136979; ua_id=TpcxMigJbsAkrTThAAAAAKsWwWWpUtqM8eWlWo4rWV4=; cert=fvT9Ks_1GAoHjaWzRl89Qw7ZwUpLosrp; uuid=2db20d72198b1c687c11cf5c039a05b8; sig=h014365e12b4d1b54d20cc57903549a28cdffe24a3263d3a0366144fbfa95ceb7850461175daad6cc37; skey=@OIuxXcd4e; data_bizuin=2391405896; data_ticket=qXfGN4TszNYU3J6Yu6BchF+41BWiTF6SIkUXx0nURJt4rXyzk0IZ/8HuKrj7QPls; master_key=3JzQHu/d/yTP3oOkLylzNEUhwHbG9z7kdsWtPlTp3js=; master_user=gh_9e6115b01729; master_sid=OGZCWWlCZXpWd2J6ejBaa2E3WWxxUFpYUFY3YXZhUEhUQjMxV0tPaXplb3hJaXBXc2JCd3A4dHFvaV9UVHF4T3VFcmowSEZ1dThSMDB2YkZNZ2tjZzg1NmgySXB3NUNIX3NURElWa29jeHY3YTc4QUZmdDVDV1VIT3B3Z3MzSU9tRlgyd1VqUlpkOXdVQmxU; master_ticket=09afde1b0bb0301ecfc65ad6435ebb98; bizuin=2391405896; slave_user=gh_9e6115b01729; slave_sid=ZWpkdHd6VlBmemVyTm9lOEZscWc2TXl0b0ZXTFdyOWJxNnBKdERKWXN5V2RVdGRXYkVoZDY1cnNaUTY2OTdsa0VPemt4bFRuTng2NXFubmQ2eHlVSXpVRkNWa3dCUXFmUmEyWmIyYWZqQXJoS05DWTdqNkk3Rm5Ya0l5OGxKQTZvY2tnVTFLdTRjdEZjb2xa'
    #cookie_str=r'RK=PSJIKXkoai; ptcz=7ce9c3e21ef9baf1cbb28edd0d05df242d03055a6a8b39a4dd2efcded83a69e0; pgv_pvid=1430614280; pgv_pvi=6390449152; XWINDEXGREY=0; o_cookie=739136979; pac_uid=1_739136979; rewardsn=; wxtokenkey=777; wxuin=2061863542; devicetype=Windows7; version=62070158; lang=zh_CN; pass_ticket=vQCPuxklro6sLz796IWNNW0lkHVj2PiSWKAPJ0SM3xmkRkYVSdZmJFUYIgjUHxwD; wap_sid2=CPaUltcHElxmMWIySDV1czFXeXQ4dzV3aGRockd2aE9UekdTZTJMRkdhUjdXMjZmMDV2Q2tnN3JtbUdQa2xxdG1vRkM3QVpHbVQ4aEJEa0xTLXRheTByQ2ZEazVWdzhFQUFBfjDSjczvBTgNQAE=; pgv_info=ssid=s3324004388; ptisp=ctc; rv2=80886B64CD45195135DD6DF62A4922480AE095E9F26A4E1065; property20=20338BFE043775EA887C6ABFA95A3D55332F2F468AD4AD809A0FBC987529B051DB1338EAEA1FDB3A; pgv_si=s6750715904; tvfe_boss_uuid=2280a21d9dc83a24; vfwebqq=d74f26fae258947b4ad441a0f0c110cdaa4d27402c061320ed18b31bca10727c1b0bdb4299fb6c5f; ied_qq=o0739136979; uin=o0739136979; ua_id=TpcxMigJbsAkrTThAAAAAKsWwWWpUtqM8eWlWo4rWV4=; cert=fvT9Ks_1GAoHjaWzRl89Qw7ZwUpLosrp; sig=h014365e12b4d1b54d20cc57903549a28cdffe24a3263d3a0366144fbfa95ceb7850461175daad6cc37; skey=@OIuxXcd4e; master_key=3JzQHu/d/yTP3oOkLylzNEUhwHbG9z7kdsWtPlTp3js=; uuid=bcfb01cb763b66188816a1ee77c02458; ticket=b843745b6f29d6dbb83367768578f4ddcc3256cf; ticket_id=gh_6fdb4ad150e8; noticeLoginFlag=1; remember_acct=wislife; rand_info=CAESILDNAlpRPS47VY6twsRplCtsJ/IY3CgJSPKhUhpOGQVP; slave_bizuin=3078893124; data_bizuin=3076976109; bizuin=3078893124; data_ticket=8gWKEsdziJlzJMNJRu8jF1Yn3DCaqfh90jx+mFMgKfaMo/83UPhQ5CbmTjB8D5nt; slave_sid=SVQ0R19Lc3lFSTJ3bld1ZzVfREZWNEJFX0RGWkxMYnh1dXBDZE8zcm9FTkRfYmxuT0JiTG5SOGZuTlFoODVmU3RmMk8wVUNLUVRUV3dVTlJtWUgxVFBQaWU4QnhqdmFNNWJSTTZRYnZCZUhaUHltMmRmeDU3TWZnUW1EVWVFaU1MNW9TUEh6YVJidHNPVzdp; slave_user=gh_6fdb4ad150e8; xid=e0b56079527dac6f23c31415dc1e20c0; openid2ticket_o7e1mt9GbHyR3H82InDoMXFWdDPM=Lb9CBB8cSZGE3eU1et5Caf7VplnEidS9DaR0s78xmU0=; mm_lang=zh_CN'
    cookie_str=r'noticeLoginFlag=1; remember_acct=peierwu; RK=PSJIKXkoai; ptcz=7ce9c3e21ef9baf1cbb28edd0d05df242d03055a6a8b39a4dd2efcded83a69e0; pgv_pvid=1430614280; pgv_pvi=6390449152; XWINDEXGREY=0; o_cookie=739136979; pac_uid=1_739136979; rewardsn=; wxtokenkey=777; wxuin=2061863542; devicetype=Windows7; version=62070158; lang=zh_CN; pass_ticket=vQCPuxklro6sLz796IWNNW0lkHVj2PiSWKAPJ0SM3xmkRkYVSdZmJFUYIgjUHxwD; wap_sid2=CPaUltcHElxmMWIySDV1czFXeXQ4dzV3aGRockd2aE9UekdTZTJMRkdhUjdXMjZmMDV2Q2tnN3JtbUdQa2xxdG1vRkM3QVpHbVQ4aEJEa0xTLXRheTByQ2ZEazVWdzhFQUFBfjDSjczvBTgNQAE=; pgv_info=ssid=s3324004388; ptisp=ctc; rv2=80886B64CD45195135DD6DF62A4922480AE095E9F26A4E1065; property20=20338BFE043775EA887C6ABFA95A3D55332F2F468AD4AD809A0FBC987529B051DB1338EAEA1FDB3A; pgv_si=s6750715904; tvfe_boss_uuid=2280a21d9dc83a24; vfwebqq=d74f26fae258947b4ad441a0f0c110cdaa4d27402c061320ed18b31bca10727c1b0bdb4299fb6c5f; ied_qq=o0739136979; uin=o0739136979; ua_id=TpcxMigJbsAkrTThAAAAAKsWwWWpUtqM8eWlWo4rWV4=; cert=fvT9Ks_1GAoHjaWzRl89Qw7ZwUpLosrp; sig=h014365e12b4d1b54d20cc57903549a28cdffe24a3263d3a0366144fbfa95ceb7850461175daad6cc37; skey=@OIuxXcd4e; master_key=3JzQHu/d/yTP3oOkLylzNEUhwHbG9z7kdsWtPlTp3js=; noticeLoginFlag=1; remember_acct=wislife; openid2ticket_o7e1mt9GbHyR3H82InDoMXFWdDPM=Lb9CBB8cSZGE3eU1et5Caf7VplnEidS9DaR0s78xmU0=; mm_lang=zh_CN; openid2ticket_oSPWJjgWWFRiGQ-2AcmLgxw32EnQ=u0w1WtLB2nkzwV32uKBn4RFRxWwtUFTkxPy6zF90jL4=; ticket_id=gh_a5b29c98c518; uuid=8f135089c4de2f5092cf475b51ede88e; ticket=028486fb4890eee8d231f8075921abd5334700b2; rand_info=CAESIAqsZQKofjrbU3EBk4vnnrdQRYGUYwf4iqe3BCb5LRBH; slave_bizuin=2399008400; data_bizuin=2395703054; bizuin=2399008400; data_ticket=ZnQrwsyOtMgyrzFhMGztVGZ+Oyel/wdtm98L55u93gInevbf1nqIBfHlDBy+1Rt9; slave_sid=b3p3aE13XzJrejZ4UGJHT1psS0FkQWVhekVhbEtLeHZPUVROVTNaOU1ZaHh2TVVWd1pxYk05dzNvMG5PU0dKWkZpaWR1NklmSWVSQUUyOFYybXFDVFhHR3ozYXI1clBnUHNlRFRldjN4elFjaGRWZGFabTEzRWxNMTNHOFVZMXE1eVUxaEpuZkN2SVdMVThO; slave_user=gh_a5b29c98c518; xid=e7203ffe2edfb2b40cb4cf41d8dcb716; openid2ticket_oDofLjoAUHALTc6iw_CxRIhzFJ2A=Cwj9bpJQBGjij6RQnVKKwtALwEkK8vg44YKtoPE/qXE='
    cookies = {}

    for line in cookie_str.split(';'):
        key, value = line.split('=', 1)
        cookies[key] = value
    response = requests.get(url, headers=headers, cookies=cookies)  # 请求访问网站
    html = response.text  # 获取网页源码
    return html  # 返回网页源码

i = 21
html = '''https://mp.weixin.qq.com/cgi-bin/newmasssendpage?count=7&begin=%d&token=1932178588&lang=zh_CN&token=1932178588&lang=zh_CN&f=json&ajax=1''' % i
wxhtml = get_html(html)  #调用函数
soup = BeautifulSoup(wxhtml,'lxml')  # 初始化BeautifulSoup库,并设置解析器
# print(soup.prettify())   #美化输出
true = True
false = False
a = eval(soup.p.string)
b = a['sent_list'][3]['appmsg_info'][1]
print(len(a['sent_list'][3]['appmsg_info']))   #获取当天的文章数
print(b)
print(b.keys())