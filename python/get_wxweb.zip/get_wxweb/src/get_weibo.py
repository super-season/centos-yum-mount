import sys
import io
import string
import requests
from bs4 import BeautifulSoup
import time,datetime
import xlwt
import json


#访问微博网站函数，返回网页源码
def get_html(url):
    headers = {
        'User-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36'
         #'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36'
        }
    #cookie_str = r'RK=PSJIKXkoai; ptcz=7ce9c3e21ef9baf1cbb28edd0d05df242d03055a6a8b39a4dd2efcded83a69e0; pgv_pvid=1430614280; pgv_pvi=6390449152; XWINDEXGREY=0; o_cookie=739136979; pac_uid=1_739136979; rewardsn=; wxtokenkey=777; wxuin=2061863542; devicetype=Windows7; version=62070158; lang=zh_CN; pass_ticket=vQCPuxklro6sLz796IWNNW0lkHVj2PiSWKAPJ0SM3xmkRkYVSdZmJFUYIgjUHxwD; wap_sid2=CPaUltcHElxmMWIySDV1czFXeXQ4dzV3aGRockd2aE9UekdTZTJMRkdhUjdXMjZmMDV2Q2tnN3JtbUdQa2xxdG1vRkM3QVpHbVQ4aEJEa0xTLXRheTByQ2ZEazVWdzhFQUFBfjDSjczvBTgNQAE=; pgv_info=ssid=s3324004388; ptisp=ctc; rv2=80886B64CD45195135DD6DF62A4922480AE095E9F26A4E1065; property20=20338BFE043775EA887C6ABFA95A3D55332F2F468AD4AD809A0FBC987529B051DB1338EAEA1FDB3A; pgv_si=s6750715904; tvfe_boss_uuid=2280a21d9dc83a24; vfwebqq=d74f26fae258947b4ad441a0f0c110cdaa4d27402c061320ed18b31bca10727c1b0bdb4299fb6c5f; ied_qq=o0739136979; uin=o0739136979; ua_id=TpcxMigJbsAkrTThAAAAAKsWwWWpUtqM8eWlWo4rWV4=; cert=fvT9Ks_1GAoHjaWzRl89Qw7ZwUpLosrp; uuid=2db20d72198b1c687c11cf5c039a05b8; sig=h014365e12b4d1b54d20cc57903549a28cdffe24a3263d3a0366144fbfa95ceb7850461175daad6cc37; skey=@OIuxXcd4e; data_bizuin=2391405896; data_ticket=qXfGN4TszNYU3J6Yu6BchF+41BWiTF6SIkUXx0nURJt4rXyzk0IZ/8HuKrj7QPls; master_key=3JzQHu/d/yTP3oOkLylzNEUhwHbG9z7kdsWtPlTp3js=; master_user=gh_9e6115b01729; master_sid=OGZCWWlCZXpWd2J6ejBaa2E3WWxxUFpYUFY3YXZhUEhUQjMxV0tPaXplb3hJaXBXc2JCd3A4dHFvaV9UVHF4T3VFcmowSEZ1dThSMDB2YkZNZ2tjZzg1NmgySXB3NUNIX3NURElWa29jeHY3YTc4QUZmdDVDV1VIT3B3Z3MzSU9tRlgyd1VqUlpkOXdVQmxU; master_ticket=09afde1b0bb0301ecfc65ad6435ebb98; bizuin=2391405896; slave_user=gh_9e6115b01729; slave_sid=ZWpkdHd6VlBmemVyTm9lOEZscWc2TXl0b0ZXTFdyOWJxNnBKdERKWXN5V2RVdGRXYkVoZDY1cnNaUTY2OTdsa0VPemt4bFRuTng2NXFubmQ2eHlVSXpVRkNWa3dCUXFmUmEyWmIyYWZqQXJoS05DWTdqNkk3Rm5Ya0l5OGxKQTZvY2tnVTFLdTRjdEZjb2xa'
    #cookie_str=r'RK=PSJIKXkoai; ptcz=7ce9c3e21ef9baf1cbb28edd0d05df242d03055a6a8b39a4dd2efcded83a69e0; pgv_pvid=1430614280; pgv_pvi=6390449152; XWINDEXGREY=0; o_cookie=739136979; pac_uid=1_739136979; rewardsn=; wxtokenkey=777; wxuin=2061863542; devicetype=Windows7; version=62070158; lang=zh_CN; pass_ticket=vQCPuxklro6sLz796IWNNW0lkHVj2PiSWKAPJ0SM3xmkRkYVSdZmJFUYIgjUHxwD; wap_sid2=CPaUltcHElxmMWIySDV1czFXeXQ4dzV3aGRockd2aE9UekdTZTJMRkdhUjdXMjZmMDV2Q2tnN3JtbUdQa2xxdG1vRkM3QVpHbVQ4aEJEa0xTLXRheTByQ2ZEazVWdzhFQUFBfjDSjczvBTgNQAE=; pgv_info=ssid=s3324004388; ptisp=ctc; rv2=80886B64CD45195135DD6DF62A4922480AE095E9F26A4E1065; property20=20338BFE043775EA887C6ABFA95A3D55332F2F468AD4AD809A0FBC987529B051DB1338EAEA1FDB3A; pgv_si=s6750715904; tvfe_boss_uuid=2280a21d9dc83a24; vfwebqq=d74f26fae258947b4ad441a0f0c110cdaa4d27402c061320ed18b31bca10727c1b0bdb4299fb6c5f; ied_qq=o0739136979; uin=o0739136979; ua_id=TpcxMigJbsAkrTThAAAAAKsWwWWpUtqM8eWlWo4rWV4=; cert=fvT9Ks_1GAoHjaWzRl89Qw7ZwUpLosrp; sig=h014365e12b4d1b54d20cc57903549a28cdffe24a3263d3a0366144fbfa95ceb7850461175daad6cc37; skey=@OIuxXcd4e; master_key=3JzQHu/d/yTP3oOkLylzNEUhwHbG9z7kdsWtPlTp3js=; uuid=bcfb01cb763b66188816a1ee77c02458; ticket=b843745b6f29d6dbb83367768578f4ddcc3256cf; ticket_id=gh_6fdb4ad150e8; noticeLoginFlag=1; remember_acct=wislife; rand_info=CAESILDNAlpRPS47VY6twsRplCtsJ/IY3CgJSPKhUhpOGQVP; slave_bizuin=3078893124; data_bizuin=3076976109; bizuin=3078893124; data_ticket=8gWKEsdziJlzJMNJRu8jF1Yn3DCaqfh90jx+mFMgKfaMo/83UPhQ5CbmTjB8D5nt; slave_sid=SVQ0R19Lc3lFSTJ3bld1ZzVfREZWNEJFX0RGWkxMYnh1dXBDZE8zcm9FTkRfYmxuT0JiTG5SOGZuTlFoODVmU3RmMk8wVUNLUVRUV3dVTlJtWUgxVFBQaWU4QnhqdmFNNWJSTTZRYnZCZUhaUHltMmRmeDU3TWZnUW1EVWVFaU1MNW9TUEh6YVJidHNPVzdp; slave_user=gh_6fdb4ad150e8; xid=e0b56079527dac6f23c31415dc1e20c0; openid2ticket_o7e1mt9GbHyR3H82InDoMXFWdDPM=Lb9CBB8cSZGE3eU1et5Caf7VplnEidS9DaR0s78xmU0=; mm_lang=zh_CN'
    #cookie_str=r'_s_tentry=www.baidu.com; Apache=1606843509420.912.1576554434591; SINAGLOBAL=1606843509420.912.1576554434591; ULV=1576554434656:1:1:1:1606843509420.912.1576554434591:; WBtopGlobal_register_version=fd6b3a12bb72ffed; SSOLoginState=1590555756; login_sid_t=ea4dc49117882ef4763cd54138eb475a; cross_origin_proto=SSL; UOR=www.228.com.cn,widget.weibo.com,www.baidu.com; SCF=AlY0U6mMXfGazkYV-WLHusBuKabVM6feZYDh0IqVoG_Ku0MlzvTVd16LGrtSyV7DfKjJqyU1_YVv4JpzCdnVqmI.; SUB=_2A25z9FQnDeRhGeRG41UU8SbNyD6IHXVQgMLvrDV8PUNbmtAKLVHckW9NTfAHtxR97jJyw_-4t2nf708_wALN8t-0; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WFyZs7z963.sfIbJ1fQBXkh5JpX5KzhUgL.FozR1hMfeKnpe0z2dJLoIEBLxKBLBonL1h5LxK-L1K5L12eLxK-LB.qL1heLxK-L1-eL1hqt; SUHB=0laVxSvWIFLI_8; ALF=1624332279; WBStorage=42212210b087ca50|undefined'
    cookie_str=r'_s_tentry=www.baidu.com; Apache=1606843509420.912.1576554434591; SINAGLOBAL=1606843509420.912.1576554434591; ULV=1576554434656:1:1:1:1606843509420.912.1576554434591:; WBtopGlobal_register_version=fd6b3a12bb72ffed; SSOLoginState=1590555756; login_sid_t=ea4dc49117882ef4763cd54138eb475a; cross_origin_proto=SSL; UOR=www.228.com.cn,widget.weibo.com,www.baidu.com; secsys_id=50d06c08a85f13bebd0fb2705049b9ea; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WFyZs7z963.sfIbJ1fQBXkh5JpX5KMhUgL.FozR1hMfeKnpe0z2dJLoIEBLxKBLBonL1h5LxK-L1K5L12eLxK-LB.qL1heLxK-L1-eL1hqt; ALF=1624862083; SCF=AlY0U6mMXfGazkYV-WLHusBuKabVM6feZYDh0IqVoG_KYv7sadUt86fqSissvyECCZCTofHANvCUhBWGcCVDqdg.; SUB=_2A25z_EpZDeRhGeRG41UU8SbNyD6IHXVQiDyRrDV8PUNbmtANLUn5kW9NTfAHtxw5Zyx3Kqn9kSYUggmat3G-tuzn; SUHB=0A0Z1YURh9ayeI; wvr=6; webim_unReadCount=%7B%22time%22%3A1593331325331%2C%22dm_pub_total%22%3A0%2C%22chat_group_client%22%3A0%2C%22chat_group_notice%22%3A0%2C%22allcountNum%22%3A0%2C%22msgbox%22%3A0%7D; WBStorage=42212210b087ca50|undefined'
    cookies = {}

    for line in cookie_str.split(';'):
        key, value = line.split('=', 1)
        cookies[key] = value
    response = requests.get(url, headers=headers, cookies=cookies)  # 请求访问网站
    html = response.text  # 获取网页源码
    return html  # 返回网页源码

#html = '''https://mp.weixin.qq.com/cgi-bin/newmasssendpage?count=7&begin=%d&token=1932178588&lang=zh_CN&token=1932178588&lang=zh_CN&f=json&ajax=1''' % i
# html = '''https://s.weibo.com/weibo?q=%E4%B9%98%E9%A3%8E%E7%A0%B4%E6%B5%AA&wvr=6&b=1&page=1'''  #微博搜索乘风破浪结果，爬取，q是question，page是页数，1-50页

n=0
out_name = 'F:/工作/FCMP项目python/get_wxweb/outfile/get_weiboweb_0628.txt'
out_name1 = 'F:/工作/FCMP项目python/get_wxweb/outfile/get_weiboname0628.txt'
out_name2 = 'F:/工作/FCMP项目python/get_wxweb/outfile/get_weibocontent0628.txt'
out_name3 = 'F:/工作/FCMP项目python/get_wxweb/outfile/get_weibobiaoqian_a.txt'
out_name4 = 'F:/工作/FCMP项目python/get_wxweb/outfile/get_weibobiaoqian_p.txt'
with open(out_name, 'w+', encoding='utf8') as f:
    f.write("网站内容：" + '\n')
with open(out_name1, 'w+', encoding='utf8') as f:
    f.write("博主名字：" + '\n')
with open(out_name2, 'w+', encoding='utf8') as f:
    f.write("博主内容：" + '\n')

for i in range(1,250):   #爬取数据主题
    html = '''https://s.weibo.com/weibo?q=乘风破浪&nodup=1&page={}'''.format(i) #也可访问https://m.weibo.cn/search?containerid=100103type%3D1%26q%3D%E4%B9%98%E9%A3%8E%E7%A0%B4%E6%B5%AA
    wxhtml = get_html(html)  #调用函数，得到网页源码
    # soup = BeautifulSoup(wxhtml,'html.parser')  # 初始化BeautifulSoup库,并设置解析器
    soup = BeautifulSoup(wxhtml,'lxml')  # 初始化BeautifulSoup库,并设置解析器

    with open(out_name, 'a+', encoding='utf8') as f:
        f.write(str(soup)+'\n')  #全部输出到本地文件,a+为权限，每次都累加在后面，不会覆盖写入，w为覆盖写入

    # a = soup.findAll('a')   #输出所有a标签的值，'p'为输出所有p标签的值
    # for j in a :
    #     print(j.text)
    #     with open(out_name3, 'a+', encoding='utf8') as f:
    #         f.write(j.text + '\n')
    # p = soup.findAll('p')   #输出所有a标签的值，'p'为输出所有p标签的值
    # for j in p :
    #     print(j.text)
    #     with open(out_name4, 'a+', encoding='utf8') as f:
    #         f.write(j.text + '\n')

    name = soup.findAll(attrs={"class" : "name"})  #输出微博名，有个标签值是class="name"
    content = soup.findAll(attrs={"class" : "txt"})  #输出微博内容，有个标签值是class="txt"，一条微博就有一个class="content"
    count = soup.findAll(attrs={"class" : "content"})  #找到所有标签值是class="content"的内容，一个content代表一篇微博，用来统计微博数

    #a =  soup.prettify()  #美化输出

    for e in name:         #输出微博名
        # print(e.get_text())   #get_text()能去除标签
        # print(e)
        # print(e.text) #text能去除标签
        with open(out_name1, 'a+', encoding='utf8') as f:
            f.write(e.text + '\n')


    for m in content:    #输出微博内容
        # print(i.get_text())   #get_text()能去除标签
        # print(i)
        # print(m.text)           #text能去除标签
        with open(out_name2, 'a+', encoding='utf8') as f:
            f.write(m.text + '\n')

    for i in count:
        n+=1
    print(n)

    time.sleep(3)