#-*- coding:utf-8 -*-

import sys
import io
import string
import requests
from bs4 import BeautifulSoup
import time,datetime
import xlwt


#访问微信公众号函数，返回网页源码
def get_html(url):
    headers = {
        'User-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36'
         #'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36'
        }
    #cookie_str = r'RK=PSJIKXkoai; ptcz=7ce9c3e21ef9baf1cbb28edd0d05df242d03055a6a8b39a4dd2efcded83a69e0; pgv_pvid=1430614280; pgv_pvi=6390449152; XWINDEXGREY=0; o_cookie=739136979; pac_uid=1_739136979; rewardsn=; wxtokenkey=777; wxuin=2061863542; devicetype=Windows7; version=62070158; lang=zh_CN; pass_ticket=vQCPuxklro6sLz796IWNNW0lkHVj2PiSWKAPJ0SM3xmkRkYVSdZmJFUYIgjUHxwD; wap_sid2=CPaUltcHElxmMWIySDV1czFXeXQ4dzV3aGRockd2aE9UekdTZTJMRkdhUjdXMjZmMDV2Q2tnN3JtbUdQa2xxdG1vRkM3QVpHbVQ4aEJEa0xTLXRheTByQ2ZEazVWdzhFQUFBfjDSjczvBTgNQAE=; pgv_info=ssid=s3324004388; ptisp=ctc; rv2=80886B64CD45195135DD6DF62A4922480AE095E9F26A4E1065; property20=20338BFE043775EA887C6ABFA95A3D55332F2F468AD4AD809A0FBC987529B051DB1338EAEA1FDB3A; pgv_si=s6750715904; tvfe_boss_uuid=2280a21d9dc83a24; vfwebqq=d74f26fae258947b4ad441a0f0c110cdaa4d27402c061320ed18b31bca10727c1b0bdb4299fb6c5f; ied_qq=o0739136979; uin=o0739136979; ua_id=TpcxMigJbsAkrTThAAAAAKsWwWWpUtqM8eWlWo4rWV4=; cert=fvT9Ks_1GAoHjaWzRl89Qw7ZwUpLosrp; uuid=2db20d72198b1c687c11cf5c039a05b8; sig=h014365e12b4d1b54d20cc57903549a28cdffe24a3263d3a0366144fbfa95ceb7850461175daad6cc37; skey=@OIuxXcd4e; data_bizuin=2391405896; data_ticket=qXfGN4TszNYU3J6Yu6BchF+41BWiTF6SIkUXx0nURJt4rXyzk0IZ/8HuKrj7QPls; master_key=3JzQHu/d/yTP3oOkLylzNEUhwHbG9z7kdsWtPlTp3js=; master_user=gh_9e6115b01729; master_sid=OGZCWWlCZXpWd2J6ejBaa2E3WWxxUFpYUFY3YXZhUEhUQjMxV0tPaXplb3hJaXBXc2JCd3A4dHFvaV9UVHF4T3VFcmowSEZ1dThSMDB2YkZNZ2tjZzg1NmgySXB3NUNIX3NURElWa29jeHY3YTc4QUZmdDVDV1VIT3B3Z3MzSU9tRlgyd1VqUlpkOXdVQmxU; master_ticket=09afde1b0bb0301ecfc65ad6435ebb98; bizuin=2391405896; slave_user=gh_9e6115b01729; slave_sid=ZWpkdHd6VlBmemVyTm9lOEZscWc2TXl0b0ZXTFdyOWJxNnBKdERKWXN5V2RVdGRXYkVoZDY1cnNaUTY2OTdsa0VPemt4bFRuTng2NXFubmQ2eHlVSXpVRkNWa3dCUXFmUmEyWmIyYWZqQXJoS05DWTdqNkk3Rm5Ya0l5OGxKQTZvY2tnVTFLdTRjdEZjb2xa'
    #cookie_str=r'RK=PSJIKXkoai; ptcz=7ce9c3e21ef9baf1cbb28edd0d05df242d03055a6a8b39a4dd2efcded83a69e0; pgv_pvid=1430614280; pgv_pvi=6390449152; XWINDEXGREY=0; o_cookie=739136979; pac_uid=1_739136979; rewardsn=; wxtokenkey=777; wxuin=2061863542; devicetype=Windows7; version=62070158; lang=zh_CN; pass_ticket=vQCPuxklro6sLz796IWNNW0lkHVj2PiSWKAPJ0SM3xmkRkYVSdZmJFUYIgjUHxwD; wap_sid2=CPaUltcHElxmMWIySDV1czFXeXQ4dzV3aGRockd2aE9UekdTZTJMRkdhUjdXMjZmMDV2Q2tnN3JtbUdQa2xxdG1vRkM3QVpHbVQ4aEJEa0xTLXRheTByQ2ZEazVWdzhFQUFBfjDSjczvBTgNQAE=; pgv_info=ssid=s3324004388; ptisp=ctc; rv2=80886B64CD45195135DD6DF62A4922480AE095E9F26A4E1065; property20=20338BFE043775EA887C6ABFA95A3D55332F2F468AD4AD809A0FBC987529B051DB1338EAEA1FDB3A; pgv_si=s6750715904; tvfe_boss_uuid=2280a21d9dc83a24; vfwebqq=d74f26fae258947b4ad441a0f0c110cdaa4d27402c061320ed18b31bca10727c1b0bdb4299fb6c5f; ied_qq=o0739136979; uin=o0739136979; ua_id=TpcxMigJbsAkrTThAAAAAKsWwWWpUtqM8eWlWo4rWV4=; cert=fvT9Ks_1GAoHjaWzRl89Qw7ZwUpLosrp; sig=h014365e12b4d1b54d20cc57903549a28cdffe24a3263d3a0366144fbfa95ceb7850461175daad6cc37; skey=@OIuxXcd4e; master_key=3JzQHu/d/yTP3oOkLylzNEUhwHbG9z7kdsWtPlTp3js=; uuid=bcfb01cb763b66188816a1ee77c02458; ticket=b843745b6f29d6dbb83367768578f4ddcc3256cf; ticket_id=gh_6fdb4ad150e8; noticeLoginFlag=1; remember_acct=wislife; rand_info=CAESILDNAlpRPS47VY6twsRplCtsJ/IY3CgJSPKhUhpOGQVP; slave_bizuin=3078893124; data_bizuin=3076976109; bizuin=3078893124; data_ticket=8gWKEsdziJlzJMNJRu8jF1Yn3DCaqfh90jx+mFMgKfaMo/83UPhQ5CbmTjB8D5nt; slave_sid=SVQ0R19Lc3lFSTJ3bld1ZzVfREZWNEJFX0RGWkxMYnh1dXBDZE8zcm9FTkRfYmxuT0JiTG5SOGZuTlFoODVmU3RmMk8wVUNLUVRUV3dVTlJtWUgxVFBQaWU4QnhqdmFNNWJSTTZRYnZCZUhaUHltMmRmeDU3TWZnUW1EVWVFaU1MNW9TUEh6YVJidHNPVzdp; slave_user=gh_6fdb4ad150e8; xid=e0b56079527dac6f23c31415dc1e20c0; openid2ticket_o7e1mt9GbHyR3H82InDoMXFWdDPM=Lb9CBB8cSZGE3eU1et5Caf7VplnEidS9DaR0s78xmU0=; mm_lang=zh_CN'
    cookie_str=r'noticeLoginFlag=1; remember_acct=peierwu; RK=PSJIKXkoai; ptcz=7ce9c3e21ef9baf1cbb28edd0d05df242d03055a6a8b39a4dd2efcded83a69e0; pgv_pvid=1430614280; pgv_pvi=6390449152; XWINDEXGREY=0; o_cookie=739136979; pac_uid=1_739136979; rewardsn=; wxtokenkey=777; wxuin=2061863542; devicetype=Windows7; version=62070158; lang=zh_CN; pass_ticket=vQCPuxklro6sLz796IWNNW0lkHVj2PiSWKAPJ0SM3xmkRkYVSdZmJFUYIgjUHxwD; wap_sid2=CPaUltcHElxmMWIySDV1czFXeXQ4dzV3aGRockd2aE9UekdTZTJMRkdhUjdXMjZmMDV2Q2tnN3JtbUdQa2xxdG1vRkM3QVpHbVQ4aEJEa0xTLXRheTByQ2ZEazVWdzhFQUFBfjDSjczvBTgNQAE=; pgv_info=ssid=s3324004388; ptisp=ctc; rv2=80886B64CD45195135DD6DF62A4922480AE095E9F26A4E1065; property20=20338BFE043775EA887C6ABFA95A3D55332F2F468AD4AD809A0FBC987529B051DB1338EAEA1FDB3A; pgv_si=s6750715904; tvfe_boss_uuid=2280a21d9dc83a24; vfwebqq=d74f26fae258947b4ad441a0f0c110cdaa4d27402c061320ed18b31bca10727c1b0bdb4299fb6c5f; ied_qq=o0739136979; uin=o0739136979; ua_id=TpcxMigJbsAkrTThAAAAAKsWwWWpUtqM8eWlWo4rWV4=; cert=fvT9Ks_1GAoHjaWzRl89Qw7ZwUpLosrp; sig=h014365e12b4d1b54d20cc57903549a28cdffe24a3263d3a0366144fbfa95ceb7850461175daad6cc37; skey=@OIuxXcd4e; master_key=3JzQHu/d/yTP3oOkLylzNEUhwHbG9z7kdsWtPlTp3js=; noticeLoginFlag=1; remember_acct=wislife; openid2ticket_o7e1mt9GbHyR3H82InDoMXFWdDPM=Lb9CBB8cSZGE3eU1et5Caf7VplnEidS9DaR0s78xmU0=; mm_lang=zh_CN; openid2ticket_oSPWJjgWWFRiGQ-2AcmLgxw32EnQ=u0w1WtLB2nkzwV32uKBn4RFRxWwtUFTkxPy6zF90jL4=; ticket_id=gh_a5b29c98c518; uuid=8f135089c4de2f5092cf475b51ede88e; ticket=028486fb4890eee8d231f8075921abd5334700b2; rand_info=CAESIAqsZQKofjrbU3EBk4vnnrdQRYGUYwf4iqe3BCb5LRBH; slave_bizuin=2399008400; data_bizuin=2395703054; bizuin=2399008400; data_ticket=ZnQrwsyOtMgyrzFhMGztVGZ+Oyel/wdtm98L55u93gInevbf1nqIBfHlDBy+1Rt9; slave_sid=b3p3aE13XzJrejZ4UGJHT1psS0FkQWVhekVhbEtLeHZPUVROVTNaOU1ZaHh2TVVWd1pxYk05dzNvMG5PU0dKWkZpaWR1NklmSWVSQUUyOFYybXFDVFhHR3ozYXI1clBnUHNlRFRldjN4elFjaGRWZGFabTEzRWxNMTNHOFVZMXE1eVUxaEpuZkN2SVdMVThO; slave_user=gh_a5b29c98c518; xid=e7203ffe2edfb2b40cb4cf41d8dcb716; openid2ticket_oDofLjoAUHALTc6iw_CxRIhzFJ2A=Cwj9bpJQBGjij6RQnVKKwtALwEkK8vg44YKtoPE/qXE='
    cookies = {}

    for line in cookie_str.split(';'):
        key, value = line.split('=', 1)
        cookies[key] = value
    response = requests.get(url, headers=headers, cookies=cookies)  # 请求访问网站
    html = response.text  # 获取网页源码
    return html  # 返回网页源码

workbook = xlwt.Workbook()     #创建工作workbook
worksheet = workbook.add_sheet('培儿屋文章统计')   #创建工作表，填入表名
worksheet.write(0,0,'文章标题')   #在工作表钟写入数据
worksheet.write(0,1,'阅读人数')
worksheet.write(0,2,'评论人数')
worksheet.write(0,3,'收藏人数')
worksheet.write(0,4,'分享人数')
worksheet.write(0,5,'发布时间')
workbook.save('F:\工作\FCMP项目python\get_wxweb\outfile\wislife.xls')  #保存表格
# i = 0     #i取值为7的倍数0,7,14,21，一页有7篇文章
n = 1    #n代表行，，第一行写了标题，需从第二行开始写
i = 0
# for i in [0,7,14,21,28,35,42,47,56,63,70,77,84,91,98,105,111,]:
while i < 1169 :
    #token为公众号的token，要换掉，i为从第i页爬取文章，一共167页，每页存7天的文章，有时候一天发布多篇文章
    html = '''https://mp.weixin.qq.com/cgi-bin/newmasssendpage?count=7&begin=%d&token=1932178588&lang=zh_CN&token=1932178588&lang=zh_CN&f=json&ajax=1''' % i
    wxhtml = get_html(html)  #调用函数，得到网页源码
    soup = BeautifulSoup(wxhtml,'lxml')  # 初始化BeautifulSoup库,并设置解析器

    #https://mp.weixin.qq.com/cgi-bin/newmasssendpage?count=10&begin=0&token=2056053385&lang=zh_CN&token=2056053385&lang=zh_CN&f=json&ajax=1

    out_name = 'F:/工作/FCMP项目python/get_wxweb/outfile/get_wxweb.txt'
    # with open(out_name, 'a+', encoding='utf8') as f:
    #     f.write(str(soup)+'\n')  #全部输出到本地文件
    # print(soup.prettify())   #美化输出
    true = True
    false = False
    a = eval(soup.p.string)

    for j in range(7):   #一页有7天内容的文章
        nn = len(a['sent_list'][j]['appmsg_info']) #获取一天中有几篇文章，若不是文章，a['sent_list'][j]['appmsg_info']为null值，while时就会跳过
        m = 0
        while m < nn:                              #同一天的每一篇文章单独获取数据
            with open(out_name, 'a+', encoding='utf8') as f:
                # f.write(str(soup)+'\n')
                try:
                    b = a['sent_list'][j]['appmsg_info'][m]  #一页中的第j天文章,j最大值为6，m为同一天的第几篇文章，嵌套关系：{字典里嵌套[数组]，数组里嵌套字典}，
                                         # appmsg_info为字典的key，该key的值为只有一个元素的列表，b为列表第m个值且类型为字典，该字典为个文章的具体参数
                except IndexError:
                    print(i,j)      #若文章有问题，输出相应的i，j，真是的页数和文章位置为(i+1,j+1)
                    continue
                timestamp = a['sent_list'][j]['sent_info']['time']  # 获得文章发布时间戳
                mid_time = time.localtime(timestamp)  # 得到相应的时间数组
                ntime = time.strftime("%Y-%m-%d", mid_time)  #得到%Y-%m-%d格式的文章发布时间
                tss = '2017-01-01 00:00:00'
                timearry = time.strptime(tss, "%Y-%m-%d %H:%M:%S")  # 时间转化为时间数组，time.struct_time(tm_year=2018，tm_mday....
                timestamp2 = int(time.mktime(timearry))  # 转化为时间戳
                # if timestamp <= timestamp2:  # 若时间戳在18年以前，则退出循环，只统计18年到现在时间段的文章
                #     exit
                # print(b)
                # print(b.keys())
                f.write('文章标题\t'+ b['title'] +'\n')
                f.write('评论人数\t'+ str(b['comment_num'])+ '\n')
                f.write('阅读人数\t'+ str(b['read_num'])+ '\n')
                f.write('收藏人数\t'+ str(b['like_num']) + '\n')
                # print('文章标题\t',b['title'])
                # print('评论人数\t',b['comment_num'])
                # print('阅读人数\t',b['read_num'])
                # print('收藏人数\t',b['like_num'])
                if 'reprint_num' in b.keys():    #判断有无分享人数reprint_num的key，没有则添加，并赋值0
                    f.write('分享人数\t'+ str(b['reprint_num']) + '\n')
                    # print('分享人数\t',b['reprint_num'] )
                else:
                    b['reprint_num'] = 0
                    f.write('分享人数\t'+ str(b['reprint_num']) + '\n')
                    # print('分享人数\t', b['reprint_num'])
                # print('发布时间\t', ntime)
                worksheet.write(n, 0, b['title'])
                worksheet.write(n, 1, b['read_num'])
                worksheet.write(n, 2, b['comment_num'])
                worksheet.write(n, 3, b['like_num'])
                worksheet.write(n, 4, b['reprint_num'])
                worksheet.write(n, 5, ntime)
                workbook.save('F:\工作\FCMP项目python\get_wxweb\outfile\peierwu3.xls')
                n += 1  #自加一行
                f.write('发布时间\t' + ntime + '\n\n')
                f.write('--------------------------------------\n')
            m += 1 #m为同一天的篇数
    i += 7
# for child in soup.body.children:
#     print(child.string)  # 遍历整个结果并输出

