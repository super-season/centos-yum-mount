#-*- coding:utf-8 -*-
import jieba
import os
import wordcloud
#import plt
import scipy.misc
import numpy


txt = open("F:/工作/FCMP项目python/get_wxweb/outfile/get_weibocontent0628new.txt", "r", encoding='utf-8').read()
out_name = 'F:/工作/FCMP项目python/get_wxweb/outfile/get_weibocipin0629.txt'
names = [
    "阿朵","白冰","陈松伶","丁当","黄圣依","黄龄","海陆","金晨",
    "金莎","蓝盈莹","李斯丹妮","刘芸","孟佳","宁静","吴昕","沈梦辰",
    "王丽坤","王霏霏","王智","万茜","许飞","郁可唯","伊能静","袁咏琳",
    "张雨绮","张含韵","张萌","钟丽缇","郑希怡","朱婧汐"]
#jieba.add_word("张雨绮")
# 更新词库，加入所分析对象的专业词汇。
# jieba.add_word('天罡北斗阵')  #逐个添加
jieba.load_userdict("./word_dict.txt")  #词库文本文件，创建一个dict.txt，然后写入你的分词,一个词占一行；每一行分三部分：词语、词频（可省略）、词性（可省略），用空格隔开，顺序不可颠倒
words  = jieba.lcut(txt)  #lcut为jieba的3模式之一：精准模式
names_count={}   #统计人名出现的次数
counts = {}
for word in words:
    if len(word) == 1:    #一个字的词就跳过
        continue
    else:
        counts[word] = counts.get(word,0) + 1  #字典的运用，更新统计的词频，counts.get(word,0)，得到key为word的值，没有则默认0

for name in names :
    names_count[name] = txt.count(name)
print(names_count)
items = list(counts.items())    #counts.items()返回所有键值对的元组数组，list再返回列表，里面元素为一个个键值对元组
items.sort(key=lambda x:x[1], reverse=True)   #key用于排序的元素，reverse=true降序，false为升序，key为取itmes的x[1]即词频数值排序,items已经更改
with open(out_name, 'w+', encoding='utf8') as f:
    f.write('微博乘风破浪搜索结果词频统计：' + '\n')
for i in range(25):
    word, count = items[i]   #items的第i个列表中的键，值
    print ("{0:<10}{1:>5}".format(word, count))
    with open(out_name, 'a+', encoding='utf8') as f:
        f.write("{0:<10}{1:>5}".format(word, count)+'\n')

with open(out_name, 'a+', encoding='utf8') as f:
    f.write('\n')
with open(out_name, 'a+', encoding='utf8') as f:
    f.write('人名词频统计：' + '\n')
for i in names_count:
    with open(out_name, 'a+', encoding='utf8') as f:
        f.write("{0:<10}{1:>5}".format(i, names_count[i])+'\n')
# 指定宽度--{：宽度}：花括号中的：冒号是固定语法，宽度直接输入想要的数值
#注:1：.format()函数默认指定宽度，对于字符串类型是左对齐，然后补齐空缺，数值类型是右对齐，然后补齐空缺
#注意2：.format()函数自定义对齐，:后使用>大于号，是右对齐； < 小于号是左对齐，^中间号是中间对齐
#注意2：.format()函数自动补齐的内容是随意的，默认补空格，想补什么类型就想在对齐方向前面即可

#根据词频生成相应的词云
wordclouds = wordcloud.WordCloud(font_path='./simhei.ttf',width=1000, height=800, margin=2, background_color='white'
                                ).generate_from_frequencies(counts)
wordclouds.to_file("../outfile/2020062903.png")

# 词频展示
# mask = np.array(Image.open('background.jpg')) # 定义词频背景
# wc = wordcloud.WordCloud(
#     background_color='white', # 设置背景颜色
#     font_path='/System/Library/Fonts/Hiragino Sans GB.ttc', # 设置字体格式
#     mask=mask, # 设置背景图
#     max_words=200, # 最多显示词数
#     max_font_size=100 , # 字体最大值
#     scale=32  # 调整图片清晰度，值越大越清楚
# )
#
# wc.generate_from_frequencies(word_counts) # 从字典生成词云
# image_colors = wordcloud.ImageColorGenerator(mask) # 从背景图建立颜色方案
# wc.recolor(color_func=image_colors) # 将词云颜色设置为背景图方案
# wc.to_file("/Users/ownpro/Desktop/temp.jpg") # 将图片输出为文件
# plt.imshow(wc) # 显示词云
# plt.axis('off') # 关闭坐标轴
# plt.show() # 显示图像