# -*- coding: utf-8 -*-
# @Time    : 2018-11-6 10:42
# @Author  : Huang Jiahao
# @Email   : 15625050341@139.com

from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
from spiders.zhaoqing_spider import ZhaoQingSpider

process = CrawlerProcess(get_project_settings())
process.crawl(ZhaoQingSpider)

process.start()
