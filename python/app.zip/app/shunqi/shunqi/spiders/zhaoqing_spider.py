# -*- coding: utf-8 -*-
# @Time    : 2018-11-5 17:44
# @Author  : Huang Jiahao
# @Email   : 15625050341@139.com

# import sys
# sys.path.append("../")
import scrapy
from shunqi.items import ShunqiItem


class ZhaoQingSpider(scrapy.Spider):
    name = 'zhaoqing'
    allowed_domains = ['www.11467.com']
    headers = {
        "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; WOW64) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/58.0.3029.110 "
                       "Safari/537.36 SE 2.X MetaSr 1.0"),
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Referer": "http://www.11467.com/zhaoqing/",
        "Host": "www.11467.com"
    }

    def start_requests(self):
        """
        爬虫入口：枚举各类黄页
        :return:
        """
        url_template = "http://www.11467.com/zhaoqing/dir/{0}.htm"
        keyword_range = map(lambda x: chr(x), range(97, 115))
        for keyword in keyword_range:
            url = url_template.format(keyword)
            yield scrapy.Request(url, callback=self.parse_last_page_num,
                                 headers=self.headers,
                                 meta={'keyword': keyword})

    def parse_last_page_num(self, response):
        """
        解析黄页尾页
        :return:
        """
        # 得到格式形如 http://www.11467.com/zhaoqing/dir/b-p8.htm
        last_page_href = response.css(
            '.pages a:last-child::attr(href)').extract_first()
        last_page_num = last_page_href.split('/')[-1][3:-4]
        keyword = response.meta['keyword']
        for page in range(1, int(last_page_num) + 1):
            url = "http://www.11467.com/zhaoqing/dir/{0}-p{1}.htm".format(
                keyword, page)
            yield scrapy.Request(url, callback=self.parse_pagination,
                                 headers=self.headers)

    def parse_pagination(self, response):
        """
        解析黄页分页内容
        :return:
        """
        companies = response.css("ul.companylist li")
        for company in companies:
            # 形如 //www.11467.com/zhaoqing/co/58307.htm
            url = "http:{}".format(company.css("div.f_l h4 a::attr(href)").extract_first())
            yield scrapy.Request(url, callback=self.parse, headers=self.headers)

    def parse(self, response):
        """
        解析企业信息
        :param response:
        :return:
        """
        item = ShunqiItem()
        item["cid"] = response.url.split('/')[-1][:-4]
        item["name"] = response.css("#logoco h1 span::text").extract_first()
        item["category"] = response.css(".navleft a::text")[3].extract()
        # null_keyword = u"未提供"
        item["address"] = response.css(".boxcontent .codl dd::text")[0].extract()
        item["tel"] = response.css(".boxcontent .codl dd::text")[1].extract()
        item["contact"] = response.css(".boxcontent .codl dd::text")[2].extract()
        item["mobile"] = response.css(".boxcontent .codl dd::text")[3].extract()
        yield item
