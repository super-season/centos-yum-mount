# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class ShunqiItem(scrapy.Item):
    # define the fields for your item here like:
    # 企业 ID
    cid = scrapy.Field()
    # 企业分类
    category = scrapy.Field()
    # 企业名
    name = scrapy.Field()
    # 企业地址
    address = scrapy.Field()
    # 固定电话
    tel = scrapy.Field()
    # 联系人
    contact = scrapy.Field()
    # 联系电话
    mobile = scrapy.Field()
