# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import ConfigParser
import pymysql
import logging

logging.basicConfig(level="INFO")


class ShunqiPipeline(object):
    def __init__(self):
        """
        连接数据库
        """
        cp = ConfigParser.SafeConfigParser()
        cp.read('config.cfg')
        try:
            self.CONN = pymysql.connect(
                host=cp.get('db', 'host'),
                port=int(cp.get('db', 'port')),
                db=cp.get('db', 'db'),
                user=cp.get('db', 'user'),
                passwd=cp.get('db', 'passwd'),
                charset='utf8'
            )
            self.CONN.autocommit(True)
            self.CURSOR = self.CONN.cursor()
        except Exception as ex:
            logging.debug(
                u'Create database connection failure, {}'.format(ex.message))

    def process_item(self, item, spider):
        if self.has_company_existed(item["cid"]):
            return item
        sql = (u"INSERT INTO `company` (`cid`, `category`, `name`, `address`, "
               u"`tel`, `contact`, `mobile`) VALUES (%(cid)s, %(category)s, "
               u"%(name)s, %(address)s, %(tel)s, %(contact)s, %(mobile)s)")
        sql_param = dict()
        sql_param['cid'] = item["cid"]
        sql_param['category'] = item["category"]
        sql_param['name'] = item["name"]
        sql_param['address'] = item["address"]
        sql_param['tel'] = item["tel"]
        sql_param['contact'] = item["contact"]
        sql_param['mobile'] = item["mobile"]

        try:
            affect_row = self.CURSOR.execute(sql, sql_param)
            if not affect_row:
                raise Exception(("Insert into table company failed, "
                                 "current cid is {}").format(item["cid"]))
        except Exception as ex:
            self.CURSOR.rollback()
            logging.debug(
                u'something wrong happened when insert data into database! ')
            logging.error(ex, exc_info=1)
        else:
            logging.info(u'insert db success!')
        finally:
            return item

    def has_company_existed(self, cid):
        """
        判断企业是否已存在
        :param cid: 企业 ID
        :return:
        """
        has_existed = False
        sql = u"SELECT COUNT(1) FROM `company` WHERE `cid`=%(cid)s"
        sql_param = dict()
        sql_param['cid'] = cid
        try:
            self.CURSOR.execute(sql, sql_param)
            count = self.CURSOR.fetchone()[0]
            if count > 0:
                has_existed = True
        except Exception as ex:
            logging.error((u'something wrong happened when searching '
                           u'company has existed or not! {}').format(ex))
        finally:
            return has_existed
