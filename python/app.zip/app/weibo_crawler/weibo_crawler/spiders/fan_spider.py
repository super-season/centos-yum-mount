# -*- coding: utf-8 -*-
import re
import datetime as dt
import scrapy
import ConfigParser
import logging
from weibo_crawler.items import AccountFansItem

logger = logging.getLogger()


class FanSpider(scrapy.Spider):
    name = 'fan_spider'
    allowed_domains = ['www.weibo.com']
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.8",
        "Accept-Encoding": "gzip, deflate, sdch, br",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 SE 2.X MetaSr 1.0",
        "Host": "weibo.com"
    }

    cookies = {
        'YF-Page-G0': 'e1a5a1aae05361d646241e28c550f987|1556276583|1556276550',
        'SUBP': '0033WrSXqPxfM72-Ws9jqgMF55529P9D9WWFvxT4lmQC3aOy7k6CX2kZ',
        'SUB': '_2AkMrnmpRf8NxqwJRmfoTzm3naIl1zw3EieKdwpuKJRMxHRl-yj83qkM9tRB6AB5Evgl_akpX-s-JBdRlwxFPv172FpN9'
    }

    def __init__(self):
        self.cp = ConfigParser.ConfigParser()
        self.cp.read('config.cfg')
        self.accounts = self.cp.get("project", "account").split(",")
        self.account_names = self.cp.get("project", "name").split(",")
        self.base_url = "https://weibo.com/{0}?is_all=1"
        self.pattern = re.compile(u"(?:他|她)的粉丝\((\d*)\)")

    def start_requests(self):
        """
        爬虫入口
        :return:
        """
        for index, account in enumerate(self.accounts):
            url = self.base_url.format(account)
            account_name = self.account_names[index]
            meta_item = {'account': account, 'name': account_name}
            logger.debug("crawling url [%s]" % url)
            yield scrapy.FormRequest(url, callback=self.parse, cookies=self.cookies,
                                     headers=self.headers, meta=meta_item)

    def parse(self, response):
        """
        获取粉丝数
        """
        item = AccountFansItem()
        groups = re.findall(self.pattern, response.text)
        if len(groups) <= 0:
            logger.error("match no fans elements. Current account is %s" % response.meta["name"])
            return
        fans = groups[0]
        item['account_id'] = response.meta["account"]
        item['account_name'] = response.meta["name"]
        item['total_fans'] = int(fans)
        now = dt.datetime.now().strftime("%Y-%m-%d %H:00:00")
        item["crawler_time"] = now
        return item
