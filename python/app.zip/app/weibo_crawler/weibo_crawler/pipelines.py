# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import ConfigParser
import pymysql
import logging

logger = logging.getLogger()


class WeiboCrawlerPipeline(object):
    def __init__(self):
        """ 连接数据库
        """
        cp = ConfigParser.SafeConfigParser()
        cp.read('config.cfg')
        try:
            self.CONN = pymysql.connect(
                host=cp.get('db', 'host'),
                port=int(cp.get('db', 'port')),
                db=cp.get('db', 'db'),
                user=cp.get('db', 'user'),
                passwd=cp.get('db', 'passwd'),
                charset='utf8'
            )
            self.CURSOR = self.CONN.cursor()
        except Exception as ex:
            logger.error(
                u'Create database connection failure, {}'.format(ex.message))



    def process_item(self, item, spider):
        sql = u"INSERT INTO `weibo_account_fans` (`account_id`, `account_name`, `update_time`, `fans_count`) VALUES (%(account_id)s, %(account_name)s, %(update_time)s, %(fans_count)s)"
        sql_param = dict()
        sql_param['account_id'] = item['account_id']
        sql_param['account_name'] = item['account_name']
        sql_param['update_time'] = item['crawler_time']
        sql_param['fans_count'] = item['total_fans']
        try:
            self.CURSOR.execute(sql, sql_param)
        except Exception as ex:
            self.CONN.rollback()
            logger.debug(u'something wrong happened when insert data into database! ')
            logger.error(ex, exc_info=1)
        else:
            self.CONN.commit()
            logger.info(u'insert db success!')
        finally:
            return item
