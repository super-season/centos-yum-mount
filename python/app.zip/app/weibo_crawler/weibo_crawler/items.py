# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class AccountFansItem(scrapy.Item):
    account_id = scrapy.Field()
    account_name = scrapy.Field()
    crawler_time = scrapy.Field()
    total_fans = scrapy.Field()
