# -*- coding: utf-8 -*-
# @Time    : 2018-9-19 14:42
# @Author  : Huang Jiahao
# @Email   : 15625050341@139.com

from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
from spiders.bid import BidSpider

process = CrawlerProcess(get_project_settings())
process.crawl(BidSpider)

process.start()
