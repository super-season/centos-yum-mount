#!/bin/bash

source /opt/cloudera/parcels/Anaconda/bin/activate py27scrapy
cd /home/huangjiahao/app/cmmc/cmmc
scrapy crawl bid >/dev/null 2>&1
source /opt/cloudera/parcels/Anaconda/bin/deactivate

