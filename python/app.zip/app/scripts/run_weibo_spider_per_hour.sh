#!/bin/bash

source /opt/cloudera/parcels/Anaconda/bin/activate py27scrapy
cd /home/huangjiahao/app/weibo_crawler/weibo_crawler
scrapy crawl fan_spider >/dev/null 2>&1
source /opt/cloudera/parcels/Anaconda/bin/deactivate

