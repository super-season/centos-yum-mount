#!/bin/bash

source /opt/cloudera/parcels/Anaconda/bin/activate py27scrapy
cd /home/huangjiahao/app/scripts
python build_csv_per_day.py >/dev/null 2>&1
source /opt/cloudera/parcels/Anaconda/bin/deactivate

