
# coding=utf8

import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from Pages.BasePage import BasePage



class LoginPage(BasePage):
    Login_name = (By.ID, u'username')
    Login_password = (By.ID, u'password')
    Login_button = (By.CLASS_NAME, u'login-button')

    #def __init__(self, driver, base_url=u'http://47.110.230.115:8080/user/login?redirect=%2Fdashboard%2Ftag'):
    #    BasePage.__init__(self, driver, base_url)

    def GoToLoginPage(self, username, password):
        #print(u'打开系统登录页面：', self.base_url)
        self.driver.get(self.base_url)
        self.driver.implicitly_wait(10)
        #print(u'输入账户名：', username)
        self.clear(self.Login_name)
        self.driver.implicitly_wait(1)
        self.input_text(self.Login_name, username)
        #print(u'输入账户密码：', password)
        self.clear(self.Login_password)
        self.driver.implicitly_wait(1)
        self.input_text(self.Login_password, password)
        #print(u'点击 登录 按钮')
        self.click(self.Login_button)
        time.sleep(2)
        #try:
        #    title = self.find_element(By.CLASS_NAME, u'copyright').text
        #except:
        #    title = None
        #if title == 'Copyright 2019 广州帷策智能科技有限公司, All Rights Reserved.':
            #print('登录成功')
        #else:
            #print('登录失败')
    def Input_Login_Text(self, name=u'testUser', mima=u'wislife_admin'):
        print(u'输入账户名：', name)
        self.input_text(self.Login_name, name)
        print(u'输入账户密码：', mima)
        self.input_text(self.Login_password, mima)

    def click_Login_btn(self):
        print(u'点击 登录 按钮')
        self.click(self.Login_button)

    def Login(self, username, password):
        #print(u'打开系统登录页面：', self.base_url)
        self.driver.get(self.base_url)
        self.driver.implicitly_wait(10)
        #print(u'输入账户名：', username)
        self.clear(self.Login_name)
        self.driver.implicitly_wait(1)
        self.input_text(self.Login_name, username)
        #print(u'输入账户密码：', password)
        self.clear(self.Login_password)
        self.driver.implicitly_wait(1)
        self.input_text(self.Login_password, password)
        #print(u'点击 登录 按钮')
        self.click(self.Login_button)
        time.sleep(2)

