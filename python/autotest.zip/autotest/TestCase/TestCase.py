#coding=utf8

import unittest
from selenium import webdriver
from selenium.webdriver.common.by import By
from Pages.BasePage import BasePage
from Pages.LoginPage import LoginPage


class TestCase(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Chrome()

    def testLogin(self):
        driver = self.driver
        url = u'http://47.110.230.115:8080/user/login?redirect=%2Fdashboard%2Ftag'
        assert_titlt = u'原力Martech客户运营云平台'
        Login_Page = LoginPage(driver, url)
        Login_Page.GoToLoginPage(username='testUser', password='wislife_admin')
        #print(Login_Page.get_title())
        self.assertEqual(assert_titlt, Login_Page.get_title())

    def testLogin12(self):
        driver = self.driver
        url = u'http://47.110.230.115:8080/user/login?redirect=%2Fdashboard%2Ftag'
        assert_titlt = u'原力Martech客户运营云平台'
        Login_Page = LoginPage(driver, url)
        Login_Page.Login(username='testUser', password='wislife_admin')
        #print(Login_Page.get_title())
        self.assertEqual(assert_titlt, Login_Page.get_title())

    def testbiaoqian(self):
        driver = self.driver
        url = u'http://47.110.230.115:8080/user/login?redirect=%2Fdashboard%2Ftag'
        BiaoQian = LoginPage(driver, url)
        BiaoQian.Login(username='testUser', password='wislife_admin')
        molus = BiaoQian.find_elements(By.CLASS_NAME, "ant-menu-item")
        a = 0
        moluStr = '目 录：'
        for a in range(molus.__len__()):
            moluStr += molus[a].text + '\t'
            molus[a].click()
            self.driver.implicitly_wait(3)
            a += 1
        #print(moluStr)
        #molus[1].click()
        #self.driver.implicitly_wait(10)
        #molus[2].click()
        #self.driver.implicitly_wait(10)
        #molus[3].click()
        #self.driver.implicitly_wait(10)
        #molus[4].click()
        #self.driver.implicitly_wait(10)
        #molus[5].click()
        #self.driver.implicitly_wait(10)
        #molus[6].click()
        #self.driver.implicitly_wait(10)
        #molus[7].click()
        #self.driver.implicitly_wait(10)
        molus[0].click()
        self.driver.implicitly_wait(10)
        KHBQ = BiaoQian.find_elements(By.XPATH, '//div[@role="tab"][@aria-disabled="false"]')
        #print(KHBQ.__len__())
        #print('客 户 标 签：', KHBQ[0].text,  KHBQ[1].text,  KHBQ[2].text,  KHBQ[3].text,  KHBQ[4].text)
        KHBQ[1].click()
        self.driver.implicitly_wait(10)
        KHBQ[2].click()
        self.driver.implicitly_wait(10)
        KHBQ[3].click()
        self.driver.implicitly_wait(10)
        KHBQ[0].click()
        self.driver.implicitly_wait(10)
        checkboxs = BiaoQian.find_elements(By.CLASS_NAME, 'ant-checkbox-input')
        self.driver.implicitly_wait(3)
        c = 0
        for c in range(checkboxs.__len__()):
            if c > 1 and c < 28:
                if c in (0, 4, 19, 25, 32, 44, 53, 61):
                    continue
                else:
                    checkboxs[c].click()
                    self.driver.implicitly_wait(3)
                c += 1
        SXBQ1 = BiaoQian.find_elements(By.XPATH, "//i[@class='anticon anticon-close']")
        self.driver.implicitly_wait(3)
        if 1 in range(SXBQ1.__len__()):
            SXBQ1[0].click()
            #print('取消选择的第一个标签类型！')
        self.driver.implicitly_wait(3)
        # 点击清空标签按钮
        BiaoQian.find_element(By.XPATH, "//button[@type='button'][@class='rechoose ant-btn ant-btn-primary ant-btn-background-ghost']").click()
        #BiaoQian.click(By.XPATH, "//button[@type='button'][@class='rechoose ant-btn ant-btn-primary ant-btn-background-ghost")
        self.driver.implicitly_wait(3)
        SXBQ2 = BiaoQian.find_elements(By.XPATH, "//i[@class='anticon anticon-close']")
        self.driver.implicitly_wait(3)
        #if SXBQ2.__len__() in (0, 1, 2):
        #    print('\t********************\t清空标签生效!\t**********************\t')
        self.assertEqual(SXBQ2.__len__(), 0)
        checkboxs[2].click()
        # 点击提交筛选按钮
        BiaoQian.find_element(By.XPATH, "//button[@type='button'][@class='select margin-r15 ant-btn ant-btn-primary']").click()
        self.driver.implicitly_wait(3)
        # 找到并打印标签筛选后的前10条数据的表头
        biaotous = BiaoQian.find_elements(By.XPATH, "//div/table/thead/tr/th[@class='']")
        btStr = '  表  头 ： '
        for biaotouItem in biaotous:
            btStr += biaotouItem.text + '\t'
        #print(' ' + btStr)
        # 找到并打印标签筛选后的前10条数据
        shujus = BiaoQian.find_elements(By.CLASS_NAME, 'ant-table-row')
        b = 0
        #for b in range(shujus.__len__()):
        #    print('第', b, '条数据：', shujus[b].text)
        #    b += 1
        title = BiaoQian.find_element(By.XPATH, "//button[@type='button'][@class='w80 ant-btn ant-btn-primary ant-btn-background-ghost']").text
        self.assertEqual(title, '关 闭')


    def tearDown(self):
        self.driver.quit()
